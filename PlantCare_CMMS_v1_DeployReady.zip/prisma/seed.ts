import { PrismaClient, Department, AssetStatus, InspectionStatus, Priority, WOStatus } from "@prisma/client";
const db = new PrismaClient();
async function main(){
  const hc=await db.asset.upsert({where:{code:"HC-001"},update:{},create:{code:"HC-001",name:"Hammer Crusher",department:Department.MECHANICAL,status:AssetStatus.RUNNING,criticality:"CRITICAL",operatingHours:4820,components:{create:["Motor","Gearbox","Fixed Bearing","Rotor","Shaft","Hammers","Hydraulic System","Fan","Lubrication System"].map(name=>({name}))}}});
  const rm=await db.asset.upsert({where:{code:"RM-001"},update:{},create:{code:"RM-001",name:"Raw Mill",department:Department.MECHANICAL,status:AssetStatus.ATTENTION,criticality:"HIGH",operatingHours:6310,components:{create:["Motor","Gearbox","Bearings","Separator","Fan","Lubrication System"].map(name=>({name}))}}});
  const bearing=await db.component.findFirst({where:{assetId:hc.id,name:"Fixed Bearing"}});
  const ins=await db.inspection.create({data:{assetId:hc.id,componentId:bearing?.id,parameter:"Horizontal Vibration",unit:"mm/s",actual:7.8,min:0,max:4.5,status:InspectionStatus.HIGH,technician:"Technician"}});
  await db.workOrder.upsert({where:{number:"WO-0001"},update:{},create:{number:"WO-0001",assetId:hc.id,componentId:bearing?.id,inspectionId:ins.id,department:Department.MECHANICAL,title:"High bearing vibration",priority:Priority.HIGH,status:WOStatus.NEW}});
  await db.sparePart.createMany({data:[
    {partNo:"BRG-6309",description:"Fixed bearing",stock:2,minStock:4,unitCost:85,location:"WH-A01"},
    {partNo:"HAM-HC01",description:"Crusher hammer",stock:18,minStock:10,unitCost:120,location:"WH-A02"},
    {partNo:"OIL-EP220",description:"Gear oil EP220",stock:3,minStock:5,unitCost:60,location:"WH-B01"}
  ],skipDuplicates:true});
  await db.pmTask.createMany({data:[
    {assetId:rm.id,title:"Gearbox Oil Analysis",frequency:"MONTHLY",dueDate:new Date("2026-09-30")},
    {assetId:hc.id,title:"Bearing Vibration Check",frequency:"WEEKLY",dueDate:new Date("2026-09-25")}
  ],skipDuplicates:true});
  await db.shutdown.upsert({where:{code:"SH-001"},update:{},create:{code:"SH-001",name:"Annual Major Maintenance",progress:42,startDate:new Date("2026-10-01"),finishDate:new Date("2026-10-21"),status:"IN PROGRESS"}});
}
main().finally(()=>db.$disconnect());