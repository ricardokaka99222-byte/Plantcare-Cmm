# PlantCare CMMS v1.0

Production-oriented starter for an industrial CMMS.

## Included
- Next.js + TypeScript
- PostgreSQL-ready data model (SQLite default for local testing)
- Prisma ORM
- Assets / Components
- Inspection with abnormal-condition workflow
- Automatic Work Order record
- PM
- Spare parts / low stock
- Shutdown
- Reports / CSV / print-to-PDF
- Kurdish / Arabic / English UI
- RTL/LTR
- Mobile responsive PWA shell
- Audit-log schema
- Role/department-ready architecture

## Run locally
1. Install Node.js 20+
2. Copy `.env.example` to `.env`
3. `npm install`
4. `npx prisma generate`
5. `npm run db:push`
6. `npm run db:seed`
7. `npm run dev`
8. Open the shown localhost URL on computer or the same network on a phone.

## Production
Use PostgreSQL, object storage for photos/documents, real authentication, push notifications, background sync, HTTPS, backups, and a managed deployment platform. The schema is designed to extend to multi-plant/multi-area operation.
