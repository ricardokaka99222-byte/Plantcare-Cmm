import {db} from "../lib/prisma";
import Dashboard from "./ui/Dashboard";

export const dynamic="force-dynamic";

export default async function Home(){
 const [assets,wo,pm,sp,shutdowns]=await Promise.all([
   db.asset.findMany({include:{components:true},orderBy:{code:"asc"}}),
   db.workOrder.findMany({include:{asset:true},orderBy:{createdAt:"desc"}}),
   db.pMTask.findMany({include:{asset:true},orderBy:{dueDate:"asc"}}),
   db.sparePart.findMany({orderBy:{stock:"asc"}}),
   db.shutdown.findMany({orderBy:{startDate:"asc"}})
 ]);
 const lowStock=sp.filter(x=>x.stock<=x.minStock).length;
 return <Dashboard initial={{assets,wo,pm,sp,shutdowns,lowStock}}/>;
}