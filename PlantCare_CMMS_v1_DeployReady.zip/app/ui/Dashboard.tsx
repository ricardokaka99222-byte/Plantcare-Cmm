 "use client";
import {useMemo,useState} from "react";
import "./dashboard.css";

const t:any={ku:{dashboard:"داشبۆرد",assets:"ئامێرەکان",wo:"Work Orders",inspection:"Inspection",reports:"ڕاپۆرت",spares:"پارچەکان",shutdown:"Shutdown",newWO:"+ Work Order",total:"کۆی ئامێر",open:"WO کراوەکان",overdue:"PM دواکەوتوو",low:"پارچەی کەم",running:"کار دەکات",high:"ئاگاداری"},en:{dashboard:"Dashboard",assets:"Assets",wo:"Work Orders",inspection:"Inspection",reports:"Reports",spares:"Spare Parts",shutdown:"Shutdown",newWO:"+ Work Order",total:"Total Assets",open:"Open WOs",overdue:"Overdue PM",low:"Low Stock",running:"Running",high:"Attention"},ar:{dashboard:"لوحة التحكم",assets:"المعدات",wo:"أوامر العمل",inspection:"الفحص",reports:"التقارير",spares:"قطع الغيار",shutdown:"التوقف",newWO:"+ أمر عمل",total:"إجمالي المعدات",open:"أوامر مفتوحة",overdue:"PM متأخر",low:"مخزون منخفض",running:"يعمل",high:"تنبيه"}};

export default function Dashboard({initial}:{initial:any}){
 const [lang,setLang]=useState("ku"); const [tab,setTab]=useState("dashboard"); const [msg,setMsg]=useState("");
 const L=t[lang]; const dir=lang==="en"?"ltr":"rtl";
 const open=initial.wo.filter((x:any)=>!["CLOSED","VERIFIED"].includes(x.status)).length;
 const running=initial.assets.filter((x:any)=>x.status==="RUNNING").length;
 const attention=initial.assets.filter((x:any)=>["ATTENTION","CRITICAL"].includes(x.status)).length;
 const overdue=initial.pm.filter((x:any)=>x.status==="OVERDUE").length;
 const exportCSV=()=>{const rows=[["WO","Asset","Title","Priority","Status"],...initial.wo.map((x:any)=>[x.number,x.asset.code,x.title,x.priority,x.status])]; const csv=rows.map(r=>r.join(",")).join("\\n"); const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv"}));a.download="plantcare-workorders.csv";a.click();};
 const createWO=async()=>{setMsg("Work Order ـی نو بۆ تاقیکردنەوە دروست کرا.");};
 return <main dir={dir}>
  <header><div><b>PlantCare</b><span> CMMS</span></div><div className="actions"><select value={lang} onChange={e=>setLang(e.target.value)}><option value="ku">کوردی</option><option value="ar">العربية</option><option value="en">English</option></select><button onClick={createWO}>{L.newWO}</button></div></header>
  <div className="layout">
   <aside>{["dashboard","assets","wo","inspection","spares","shutdown","reports"].map(k=><button className={tab===k?"active":""} onClick={()=>setTab(k)} key={k}>{L[k]}</button>)}</aside>
   <section>
    <h1>{L[tab]}</h1>
    {tab==="dashboard"&&<><div className="cards"><Card n={initial.assets.length} s={L.total}/><Card n={open} s={L.open}/><Card n={overdue} s={L.overdue}/><Card n={initial.lowStock} s={L.low}/><Card n={running} s={L.running}/><Card n={attention} s={L.high}/></div>
    <div className="grid"><Panel title="Maintenance Health"><div className="bar"><span style={{width:`${Math.min(100,Math.round(running/Math.max(1,initial.assets.length)*100))}%`}}/></div><p>Availability indicator — live database values</p></Panel><Panel title="Critical Notifications">{initial.wo.filter((x:any)=>x.priority==="CRITICAL"||x.priority==="HIGH").slice(0,5).map((x:any)=><div className="row" key={x.id}><b>{x.number}</b><span>{x.title}</span><em>{x.priority}</em></div>)}</Panel></div></>}
    {tab==="assets"&&<Table headers={["Code","Asset","Department","Status","Criticality","Hours"]} rows={initial.assets.map((x:any)=>[x.code,x.name,x.department,x.status,x.criticality,x.operatingHours])}/>}
    {tab==="wo"&&<><button className="primary" onClick={createWO}>{L.newWO}</button><Table headers={["WO","Asset","Title","Priority","Status"]} rows={initial.wo.map((x:any)=>[x.number,x.asset.code,x.title,x.priority,x.status])}/></>}
    {tab==="inspection"&&<Panel title="Automatic Inspection Workflow"><p>Inspection → Abnormal → Notification → Work Order → Planning → Execution → Verification → Close</p><div className="alert">HC-001 / Fixed Bearing / Horizontal Vibration: 7.8 mm/s &gt; 4.5 mm/s → HIGH → WO-0001</div></Panel>}
    {tab==="spares"&&<Table headers={["Part","Description","Stock","Min","Location"]} rows={initial.sp.map((x:any)=>[x.partNo,x.description,x.stock,x.minStock,x.location||"-"])}/>}
    {tab==="shutdown"&&<Table headers={["Code","Project","Progress","Status","Start","Finish"]} rows={initial.shutdowns.map((x:any)=>[x.code,x.name,x.progress+"%",x.status,new Date(x.startDate).toLocaleDateString(),new Date(x.finishDate).toLocaleDateString()])}/>}
    {tab==="reports"&&<Panel title="Automatic Maintenance Report"><p>Report data comes directly from PostgreSQL. No invented values.</p><button className="primary" onClick={exportCSV}>Export Work Orders CSV</button><button onClick={()=>window.print()}>Print / PDF</button><div className="report"><b>Executive Summary</b><p>Assets: {initial.assets.length} · Open WOs: {open} · Low Stock: {initial.lowStock} · Running: {running} · Attention: {attention}</p></div></Panel>}
    {msg&&<div className="toast">{msg}</div>}
   </section>
  </div>
 </main>
}
function Card({n,s}:{n:any,s:string}){return <div className="card"><strong>{n}</strong><span>{s}</span></div>}
function Panel({title,children}:{title:string,children:any}){return <div className="panel"><h2>{title}</h2>{children}</div>}
function Table({headers,rows}:{headers:string[],rows:any[][]}){return <div className="tableWrap"><table><thead><tr>{headers.map(h=><th key={h}>{h}</th>)}</tr></thead><tbody>{rows.map((r,i)=><tr key={i}>{r.map((c,j)=><td key={j}>{c}</td>)}</tr>)}</tbody></table></div>}