import "./globals.css";
export const metadata={title:"PlantCare CMMS",description:"Industrial maintenance management system"};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="ku" dir="rtl"><body>{children}</body></html>}